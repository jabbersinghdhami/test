<div class="mkdf-testimonials-item-holder">
    <div <?php mkd_core_inline_style($content_styles); ?> id="mkdf-testimonials<?php echo esc_attr($current_id) ?>" <?php mkd_core_class_attribute($holder_classes); ?>>
        <div class="mkdf-testimonial-content-inner">
            <?php if (has_post_thumbnail($current_id)) { ?>
                <div class="mkdf-testimonial-image-holder">
                    <?php esc_html(the_post_thumbnail($current_id)) ?>
                </div>
            <?php } ?>
            <div class="mkdf-testimonial-text-holder">
                <div class="mkdf-testimonial-text-inner">
                    <p class="mkdf-testimonial-text"><?php echo trim($text) ?></p>
                </div>
            </div>
        </div>
        <div class="mkdf-rating">
            <?php if ($stars == '0' ) : ?>
                <span aria-hidden="true" class="icon_star_alt"></span>
                <span aria-hidden="true" class="icon_star_alt"></span>
                <span aria-hidden="true" class="icon_star_alt"></span>
                <span aria-hidden="true" class="icon_star_alt"></span>
                <span aria-hidden="true" class="icon_star_alt"></span>

            <?php elseif ($stars == '1' ) : ?>
                <span aria-hidden="true" class="icon_star"></span>
                <span aria-hidden="true" class="icon_star_alt"></span>
                <span aria-hidden="true" class="icon_star_alt"></span>
                <span aria-hidden="true" class="icon_star_alt"></span>
                <span aria-hidden="true" class="icon_star_alt"></span>

            <?php elseif ($stars == '2' ) : ?>
                <span aria-hidden="true" class="icon_star"></span>
                <span aria-hidden="true" class="icon_star"></span>
                <span aria-hidden="true" class="icon_star_alt"></span>
                <span aria-hidden="true" class="icon_star_alt"></span>
                <span aria-hidden="true" class="icon_star_alt"></span>

            <?php elseif ($stars == '3' ) : ?>
                <span aria-hidden="true" class="icon_star"></span>
                <span aria-hidden="true" class="icon_star"></span>
                <span aria-hidden="true" class="icon_star"></span>
                <span aria-hidden="true" class="icon_star_alt"></span>
                <span aria-hidden="true" class="icon_star_alt"></span>

            <?php elseif ($stars == '4' ) : ?>
                <span aria-hidden="true" class="icon_star"></span>
                <span aria-hidden="true" class="icon_star"></span>
                <span aria-hidden="true" class="icon_star"></span>
                <span aria-hidden="true" class="icon_star"></span>
                <span aria-hidden="true" class="icon_star_alt"></span>

            <?php elseif ($stars == '5' ) : ?>
                <span aria-hidden="true" class="icon_star"></span>
                <span aria-hidden="true" class="icon_star"></span>
                <span aria-hidden="true" class="icon_star"></span>
                <span aria-hidden="true" class="icon_star"></span>
                <span aria-hidden="true" class="icon_star"></span>
            <?php endif; ?>
        </div>

        <?php if ($show_author == "yes") { ?>
            <div class = "mkdf-testimonial-author" <?php mkd_core_inline_style($author_styles); ?>>
                <span class="mkdf-testimonial-author-text"><?php echo esc_html($author)?></span>
            </div>
        <?php } ?>
    </div>
</div>

