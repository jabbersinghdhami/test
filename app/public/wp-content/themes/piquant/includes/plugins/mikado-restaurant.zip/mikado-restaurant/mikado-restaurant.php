<?php
/*
Plugin Name: Mikado Restaurant
Description: Plugin that adds all restaurant post types, shortcodes and OpenTable integration
Author: Mikado Themes
Version: 1.0
*/

require_once 'load.php';

use MikadoRestaurant\CPT;
use MikadoRestaurant\Lib;

add_action('after_setup_theme', array(CPT\PostTypesRegister::getInstance(), 'register'));

Lib\ShortcodeLoader::getInstance()->load();

if(!function_exists('mkd_restaurant_activation')) {
	/**
	 * Triggers when plugin is activated. It calls flush_rewrite_rules
	 * and defines mkd_restaurant_on_activate action
	 */
	function mkd_restaurant_activation() {
		do_action('mkd_restaurant_on_activate');

		MikadoRestaurant\CPT\PostTypesRegister::getInstance()->register();
		flush_rewrite_rules();
	}

	register_activation_hook(__FILE__, 'mkd_restaurant_activation');
}

if(!function_exists('mkd_restaurant_text_domain')) {
	/**
	 * Loads plugin text domain so it can be used in translation
	 */
	function mkd_restaurant_text_domain() {
		load_plugin_textdomain('mkd_restaurant', false, MIKADO_RESTAURANT_REL_PATH.'/languages');
	}

	add_action('plugins_loaded', 'mkd_restaurant_text_domain');
}