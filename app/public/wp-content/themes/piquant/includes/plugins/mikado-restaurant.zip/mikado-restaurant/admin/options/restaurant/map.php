<?php

if(mkd_restaurant_theme_installed()) {
	if(!function_exists('mkd_restaurant_map_map')) {
		/**
		 * Adds admin page for OpenTable integration
		 */
		function mkd_restaurant_map_map() {
			piquant_mikado_add_admin_page(array(
				'title' => 'Restaurant',
				'slug'  => '_restaurant',
				'icon'  => 'fa fa-cutlery'
			));

			//#OpenTable Panel
			$panel_open_table = piquant_mikado_add_admin_panel(array(
				'page'  => '_restaurant',
				'name'  => 'panel_open_table',
				'title' => 'OpenTable'
			));

			piquant_mikado_add_admin_field(array(
				'name'        => 'open_table_id',
				'type'        => 'text',
				'label'       => 'OpenTable ID',
				'description' => 'Add your restaurant\'s OpenTable ID',
				'parent'      => $panel_open_table,
				'args'        => array(
					'col_width' => 3
				)
			));

			//#Working Hours panel
			$panel_working_hours = piquant_mikado_add_admin_panel(array(
				'page'  => '_restaurant',
				'name'  => 'panel_working_hours',
				'title' => 'Working Hours'
			));

			$monday_group = piquant_mikado_add_admin_group(array(
				'name'        => 'monday_group',
				'title'       => 'Monday',
				'parent'      => $panel_working_hours,
				'description' => 'Working hours for Monday'
			));

			$monday_row = piquant_mikado_add_admin_row(array(
				'name'   => 'monday_row',
				'parent' => $monday_group
			));

			piquant_mikado_add_admin_field(array(
				'name'   => 'wh_monday_from',
				'type'   => 'textsimple',
				'label'  => 'From',
				'parent' => $monday_row
			));

			piquant_mikado_add_admin_field(array(
				'name'   => 'wh_monday_to',
				'type'   => 'textsimple',
				'label'  => 'To',
				'parent' => $monday_row
			));

			$tuesday_group = piquant_mikado_add_admin_group(array(
				'name'        => 'tuesday_group',
				'title'       => 'Tuesday',
				'parent'      => $panel_working_hours,
				'description' => 'Working hours for Tuesday'
			));

			$tuesday_row = piquant_mikado_add_admin_row(array(
				'name'   => 'tuesday_row',
				'parent' => $tuesday_group
			));

			piquant_mikado_add_admin_field(array(
				'name'   => 'wh_tuesday_from',
				'type'   => 'textsimple',
				'label'  => 'From',
				'parent' => $tuesday_row
			));

			piquant_mikado_add_admin_field(array(
				'name'   => 'wh_tuesday_to',
				'type'   => 'textsimple',
				'label'  => 'To',
				'parent' => $tuesday_row
			));

			$wednesday_group = piquant_mikado_add_admin_group(array(
				'name'        => 'wednesday_group',
				'title'       => 'Wednesday',
				'parent'      => $panel_working_hours,
				'description' => 'Working hours for Wednesday'
			));

			$wednesday_row = piquant_mikado_add_admin_row(array(
				'name'   => 'wednesday_row',
				'parent' => $wednesday_group
			));

			piquant_mikado_add_admin_field(array(
				'name'   => 'wh_wednesday_from',
				'type'   => 'textsimple',
				'label'  => 'From',
				'parent' => $wednesday_row
			));

			piquant_mikado_add_admin_field(array(
				'name'   => 'wh_wednesday_to',
				'type'   => 'textsimple',
				'label'  => 'To',
				'parent' => $wednesday_row
			));

			$thursday_group = piquant_mikado_add_admin_group(array(
				'name'        => 'thursday_group',
				'title'       => 'Thursday',
				'parent'      => $panel_working_hours,
				'description' => 'Working hours for Thursday'
			));

			$thursday_row = piquant_mikado_add_admin_row(array(
				'name'   => 'thursday_row',
				'parent' => $thursday_group
			));

			piquant_mikado_add_admin_field(array(
				'name'   => 'wh_thursday_from',
				'type'   => 'textsimple',
				'label'  => 'From',
				'parent' => $thursday_row
			));

			piquant_mikado_add_admin_field(array(
				'name'   => 'wh_thursday_to',
				'type'   => 'textsimple',
				'label'  => 'To',
				'parent' => $thursday_row
			));

			$friday_group = piquant_mikado_add_admin_group(array(
				'name'        => 'friday_group',
				'title'       => 'Friday',
				'parent'      => $panel_working_hours,
				'description' => 'Working hours for Friday'
			));

			$friday_row = piquant_mikado_add_admin_row(array(
				'name'   => 'friday_row',
				'parent' => $friday_group
			));

			piquant_mikado_add_admin_field(array(
				'name'   => 'wh_friday_from',
				'type'   => 'textsimple',
				'label'  => 'From',
				'parent' => $friday_row
			));

			piquant_mikado_add_admin_field(array(
				'name'   => 'wh_friday_to',
				'type'   => 'textsimple',
				'label'  => 'To',
				'parent' => $friday_row
			));

			$saturday_group = piquant_mikado_add_admin_group(array(
				'name'        => 'saturday_group',
				'title'       => 'Saturday',
				'parent'      => $panel_working_hours,
				'description' => 'Working hours for Saturday'
			));

			$saturday_row = piquant_mikado_add_admin_row(array(
				'name'   => 'saturday_row',
				'parent' => $saturday_group
			));

			piquant_mikado_add_admin_field(array(
				'name'   => 'wh_saturday_from',
				'type'   => 'textsimple',
				'label'  => 'From',
				'parent' => $saturday_row
			));

			piquant_mikado_add_admin_field(array(
				'name'   => 'wh_saturday_to',
				'type'   => 'textsimple',
				'label'  => 'To',
				'parent' => $saturday_row
			));

			$sunday_group = piquant_mikado_add_admin_group(array(
				'name'        => 'sunday_group',
				'title'       => 'Sunday',
				'parent'      => $panel_working_hours,
				'description' => 'Working hours for Sunday'
			));

			$sunday_row = piquant_mikado_add_admin_row(array(
				'name'   => 'sunday_row',
				'parent' => $sunday_group
			));

			piquant_mikado_add_admin_field(array(
				'name'   => 'wh_sunday_from',
				'type'   => 'textsimple',
				'label'  => 'From',
				'parent' => $sunday_row
			));

			piquant_mikado_add_admin_field(array(
				'name'   => 'wh_sunday_to',
				'type'   => 'textsimple',
				'label'  => 'To',
				'parent' => $sunday_row
			));
		}

		add_action('piquant_mikado_options_map', 'mkd_restaurant_map_map', 10);
	}
}

if(!function_exists('mkd_restaurant_menu_item_single_map')) {
	function mkd_restaurant_menu_item_single_map() {
		//#OpenTable Panel
		$panel_single = piquant_mikado_add_admin_panel(array(
			'page'  => '_restaurant',
			'name'  => 'panel_menu_item_single',
			'title' => 'Menu Item Single Page'
		));

		piquant_mikado_add_admin_field(array(
			'name'          => 'menu_item_show_navigation',
			'type'          => 'yesno',
			'default_value' => 'yes',
			'label'         => 'Enable Navigation Through Posts',
			'description'   => 'Enabling this option will display previous and next posts links',
			'parent'        => $panel_single
		));

		piquant_mikado_add_admin_field(array(
			'name'          => 'menu_item_show_author_info',
			'type'          => 'yesno',
			'default_value' => 'yes',
			'label'         => 'Show Author Info Section',
			'description'   => 'Enabling this option will display author info section',
			'parent'        => $panel_single
		));

		piquant_mikado_add_admin_field(array(
			'name'          => 'menu_item_enable_comments',
			'type'          => 'yesno',
			'default_value' => 'yes',
			'label'         => 'Enable Comments',
			'description'   => 'Enabling this option will display comments',
			'parent'        => $panel_single
		));

		piquant_mikado_add_admin_field(array(
			'name'          => 'menu_item_show_preparation_info',
			'type'          => 'yesno',
			'default_value' => 'yes',
			'label'         => 'Show Preparation Info Section',
			'description'   => 'Enabling this option will display preparation info section in sidebar',
			'parent'        => $panel_single
		));

		piquant_mikado_add_admin_field(array(
			'name'          => 'menu_item_show_related',
			'type'          => 'yesno',
			'default_value' => 'yes',
			'label'         => 'Show Related Menu Items',
			'description'   => 'Enabling this option will display related menu items in sidebar',
			'parent'        => $panel_single,
			'args'          => array(
				'dependence'             => true,
				'dependence_show_on_yes' => '#mkdf_menu_item_related_container'
			)
		));

		$related_container = piquant_mikado_add_admin_container(array(
			'parent'          => $panel_single,
			'name'            => 'menu_item_related_container',
			'hidden_property' => 'menu_item_show_related',
			'hidden_value'    => 'no'
		));

		piquant_mikado_add_admin_field(array(
			'name'          => 'menu_item_related_image_size',
			'type'          => 'select',
			'default_value' => 'portfolio-landscape',
			'label'         => 'Related Menu Item Image Proportion',
			'description'   => 'Choose related menu item image proportion',
			'parent'        => $related_container,
			'options'       => array(
				'full'                => 'Original',
				'portfolio-square'    => 'Square',
				'portfolio-landscape' => 'Landscape',
			    'portfolio-portrait'  => 'Portrait'
			)
		));
	}

	add_action('piquant_mikado_options_map', 'mkd_restaurant_menu_item_single_map', 10);
}