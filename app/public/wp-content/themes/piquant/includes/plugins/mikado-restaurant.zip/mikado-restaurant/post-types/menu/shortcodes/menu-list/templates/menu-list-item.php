<?php extract(mkd_restaurant_get_menu_meta()); ?>
<li class="mkdf-ml-item clearfix">
	<?php if($show_featured_image === 'yes') : ?>
			<div class="mkdf-ml-item-image">
				<a href="<?php echo esc_url(wp_get_attachment_url(get_post_thumbnail_id())); ?>" data-rel="prettyPhoto<?php echo esc_attr(the_ID()); ?>">
					<?php the_post_thumbnail('thumbnail'); ?>
				</a>
			</div>
	<?php endif; ?>
	<div class="mkdf-ml-item-content">
		<div class="mkdf-ml-top-holder">
			<div class="mkdf-ml-title-holder">
				<h4 class="mkdf-ml-title">
					<a href="<?php esc_url(the_permalink()); ?>"><?php esc_html(the_title()); ?></a></h4>
			</div>
			<div class="mkdf-ml-dots"></div>

			<?php if(!empty($price)) : ?>
				<div class="mkdf-ml-price-holder">
					<h4 class="mkdf-ml-price"><?php echo esc_html($price); ?></h4>
				</div>

			<?php endif; ?>
		</div>
		<div class="mkdf-ml-bottom-holder clearfix">
			<div class="mkdf-ml-excerpt-holder">
				<?php the_excerpt(); ?>
			</div>

			<?php if(!empty($label)) : ?>
				<div class="mkdf-ml-label-holder">
					<span class="mkdf-ml-label"><?php echo esc_html($label); ?></span>
				</div>
			<?php endif; ?>
		</div>
	</div>

</li>
