<?php
extract(mkd_restaurant_get_menu_meta('grid'));
$price_class = !empty($price) ? 'mkdf-mg-with-price' : '';
?>
<li <?php post_class($price_class); ?>>
	<?php if(has_post_thumbnail()) : ?>
		<div class="mkdf-mg-image-holder">
			<a href="<?php echo esc_url(wp_get_attachment_url(get_post_thumbnail_id())); ?>" data-rel="prettyPhotoMenuGrid<?php echo esc_attr(get_the_ID()); ?>">
				<?php the_post_thumbnail($image_proportion); ?>

				<span class="mkdf-mg-overlay"></span>
				<?php if(!empty($label)) : ?>
					<span class="mkdf-mg-label-holder">
						<span class="mkdf-mg-label"><?php echo esc_html($label); ?></span>
					</span>
				<?php endif; ?>

			</a>
		</div>
	<?php endif; ?>
	<div class="mkdf-mg-content-holder">
		<?php if(!empty($price)) : ?>
			<div class="mkdf-mg-price-holder">
				<span class="mkdf-mg-price">
					<span><?php echo esc_html($price); ?></span>
				</span>
			</div>
		<?php endif; ?>
		<div class="mkdf-mg-title-holder">
			<h4 class="mkdf-mg-title"><a href="<?php esc_url(the_permalink()); ?>"><?php esc_html(the_title()); ?></a></h4>
		</div>
		<div class="mkdf-bg-excerpt-holder">
			<?php the_excerpt(); ?>
		</div>
	</div>
</li>