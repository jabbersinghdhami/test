<?php

if(!function_exists('mkd_restaurant_menu_meta_box_save')) {
	function mkd_restaurant_menu_meta_box_save($post_types) {
		$post_types[] = 'restaurant-menu-item';

		return $post_types;
	}

	add_filter('piquant_mikado_meta_box_post_types_save', 'mkd_restaurant_menu_meta_box_save');
}

if(!function_exists('mkd_restaurant_get_menu_meta')) {
    function mkd_restaurant_get_menu_meta($type = 'list') {
        $meta = array();

	    $price = get_post_meta(get_the_ID(), 'mkdf_menu_item_price_meta', true);
	    $meta['price'] = $price;

	    $label = get_post_meta(get_the_ID(), 'mkdf_menu_item_label', true);
	    $meta['label'] = $label;

		if($type == 'list') {

		}

	    return $meta;
    }
}