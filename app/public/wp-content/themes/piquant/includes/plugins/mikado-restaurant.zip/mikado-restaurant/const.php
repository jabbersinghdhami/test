<?php

define('MIKADO_RESTAURANT_VERSION', '1.0');
define('MIKADO_RESTAURANT_ABS_PATH', dirname(__FILE__));
define('MIKADO_RESTAURANT_REL_PATH', dirname(plugin_basename(__FILE__ )));
define('MIKADO_RESTAURANT_CPT_PATH', MIKADO_RESTAURANT_ABS_PATH.'/post-types');