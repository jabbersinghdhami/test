<?php

if(!function_exists('mkd_restaurant_menu_map')) {
	function mkd_restaurant_menu_map() {
		$general_meta_box = piquant_mikado_add_meta_box(array(
			'scope' => array('restaurant-menu-item'),
			'title' => 'Menu Item Settings',
			'name'  => 'menu_item_settings'
		));

		piquant_mikado_add_meta_box_field(array(
			'name'          => 'mkdf_menu_item_price_meta',
			'type'          => 'text',
			'default_value' => '',
			'label'         => 'Menu Item Price',
			'description'   => 'Enter price for this menu item',
			'parent'        => $general_meta_box,
			'args'          => array(
				'col_width' => '3'
			)
		));

		piquant_mikado_add_meta_box_field(array(
			'name'          => 'mkdf_menu_item_label',
			'type'          => 'text',
			'default_value' => '',
			'label'         => 'Menu Item Label',
			'description'   => 'Enter label for this menu item',
			'parent'        => $general_meta_box,
			'args'          => array(
				'col_width' => '3'
			)
		));

		piquant_mikado_add_meta_box_field(array(
			'name'          => 'mkdf_menu_item_prep_time_meta',
			'type'          => 'text',
			'default_value' => '',
			'label'         => 'Menu Item Preparation Time',
			'description'   => 'Enter preparation time for this menu item',
			'parent'        => $general_meta_box,
			'args'          => array(
				'col_width' => '3'
			)
		));

		piquant_mikado_add_meta_box_field(array(
			'name'          => 'mkdf_menu_item_cook_time_meta',
			'type'          => 'text',
			'default_value' => '',
			'label'         => 'Menu Item Cooking Time',
			'description'   => 'Enter cooking time for this menu item',
			'parent'        => $general_meta_box,
			'args'          => array(
				'col_width' => '3'
			)
		));

		piquant_mikado_add_meta_box_field(array(
			'name'          => 'mkdf_menu_item_servings_num_meta',
			'type'          => 'text',
			'default_value' => '',
			'label'         => 'Menu Item Number of Servings',
			'description'   => 'Enter number of servings for this menu item',
			'parent'        => $general_meta_box,
			'args'          => array(
				'col_width' => '3'
			)
		));

		piquant_mikado_add_meta_box_field(array(
			'name'          => 'mkdf_menu_item_calories_num_meta',
			'type'          => 'text',
			'default_value' => '',
			'label'         => 'Menu Item Calories',
			'description'   => 'Enter number of calories for this menu item',
			'parent'        => $general_meta_box,
			'args'          => array(
				'col_width' => '3'
			)
		));

		piquant_mikado_add_meta_box_field(array(
			'name'          => 'mkdf_menu_item_ready_in_meta',
			'type'          => 'text',
			'default_value' => '',
			'label'         => 'Menu Item Ready In',
			'description'   => 'Enter necessary time to prepare this menu item',
			'parent'        => $general_meta_box,
			'args'          => array(
				'col_width' => '3'
			)
		));

		piquant_mikado_add_meta_box_field(array(
			'name'          => 'mkdf_menu_item_ingredients_meta',
			'type'          => 'textarea',
			'default_value' => '',
			'label'         => 'Menu Item Ingredients',
			'description'   => 'Enter menu item ingredients. Separate each ingredient with new line (enter).',
			'parent'        => $general_meta_box,
			'args'          => array(
				'col_width' => '3'
			)
		));
	}

	add_action('piquant_mikado_meta_boxes_map', 'mkd_restaurant_menu_map');
}

if(!function_exists('mkd_restaurant_menu_item_gallery_map')) {
	function mkd_restaurant_menu_item_gallery_map() {
		$meta_box = piquant_mikado_add_meta_box(array(
			'scope' => array('restaurant-menu-item'),
			'title' => 'Menu Item Gallery',
			'name'  => 'menu_item_gallery'
		));

		piquant_mikado_add_meta_box_field(array(
			'type'          => 'multipleimages',
			'name'          => 'mkdf_menu_item_gallery_meta',
			'default_value' => '',
			'label'         => 'Menu Item Gallery',
			'description'   => 'Choose gallery images for this menu item',
			'parent'        => $meta_box
		));
	}

	add_action('piquant_mikado_meta_boxes_map', 'mkd_restaurant_menu_item_gallery_map');
}