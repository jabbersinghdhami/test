<?php
namespace MikadoRestaurant\Shortcodes;

use MikadoRestaurant\Lib\ShortcodeInterface;

class ReservationForm implements ShortcodeInterface {
	private $base;

	public function __construct() {
		$this->base = 'mkdf_reservation_form';

		add_action('vc_before_init', array($this, 'vcMap'));
	}

	public function getBase() {
		return $this->base;
	}

	public function vcMap() {
		vc_map(array(
			'name'                      => 'Mikado Reservation Form',
			'base'                      => $this->base,
			'category'                  => 'by MIKADO',
			'icon'                      => '',
			'allowed_container_element' => 'vc_row',
			'params'                    => array(
				array(
					'type'        => 'textfield',
					'heading'     => 'OpenTable ID',
					'param_name'  => 'open_table_id',
					'admin_label' => true
				)
			)
		));
	}

	public function render($atts, $content = null) {
		$default_atts = array(
			'open_table_id' => ''
		);

		$params = shortcode_atts($default_atts, $atts);

		if($params['open_table_id'] === '' && mkd_restaurant_theme_installed()) {
			$params['open_table_id'] = piquant_mikado_options()->getOptionValue('open_table_id');
		}

		return mkd_restaurant_get_template_part('shortcodes/reservation-form/templates/reservation-form', '', $params, true);
	}

}