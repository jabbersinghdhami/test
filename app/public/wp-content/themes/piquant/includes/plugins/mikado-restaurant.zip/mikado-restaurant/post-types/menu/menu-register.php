<?php
namespace MikadoRestaurant\CPT\Menu;

use MikadoRestaurant\Lib\PostTypeInterface;

class Menu implements PostTypeInterface {
	/**
	 * @var string
	 */
	private $base;
	/**
	 * @var string
	 */
	private $taxBase;

	public function __construct() {
		$this->base    = 'restaurant-menu-item';
		$this->taxBase = 'restaurant-menu-section';
	}

	/**
	 * @return string
	 */
	public function getBase() {
		return $this->base;
	}

	public function register() {
		$this->registerPostType();
		$this->registerTax();
	}

	/**
	 * Regsiters custom post type with WordPress
	 */
	private function registerPostType() {
		$menuPosition = 5;
		$menuIcon     = 'dashicons-admin-post';

		register_post_type($this->base,
			array(
				'labels'        => array(
					'name'          => __('Restaurant Menu', 'mkd_restaurant'),
					'menu_name'     => __('Restaurant Menu', 'mkd_restaurant'),
					'all_items'     => __('Menu Items', 'mkd_restaurant'),
					'add_new'       => __('Add New Menu Item', 'mkd_restaurant'),
					'singular_name' => __('Menu Item', 'mkd_restaurant'),
					'add_item'      => __('New Menu Item', 'mkd_restaurant'),
					'add_new_item'  => __('Add New Menu Item', 'mkd_restaurant'),
					'edit_item'     => __('Edit Menu Item', 'mkd_restaurant')
				),
				'public'        => true,
				'show_in_menu'  => true,
				'rewrite'       => array('slug' => 'menu-item'),
				'menu_position' => $menuPosition,
				'show_ui'       => true,
				'has_archive'   => false,
				'hierarchical'  => false,
				'supports'      => array('title', 'thumbnail', 'excerpt', 'editor', 'comments', 'author'),
				'menu_icon'     => $menuIcon
			)
		);
	}

	/**
	 * Registers custom taxonomy with WordPress
	 */
	private function registerTax() {
		$labels = array(
			'name'              => __('Menu Section', 'mkd_restaurant'),
			'singular_name'     => __('Menu Section', 'mkd_restaurant'),
			'search_items'      => __('Search Menu Sections', 'mkd_restaurant'),
			'all_items'         => __('All Menu Sections', 'mkd_restaurant'),
			'parent_item'       => __('Parent Menu Section', 'mkd_restaurant'),
			'parent_item_colon' => __('Parent Menu Section:', 'mkd_restaurant'),
			'edit_item'         => __('Edit Menu Section', 'mkd_restaurant'),
			'update_item'       => __('Update Menu Section', 'mkd_restaurant'),
			'add_new_item'      => __('Add New Menu Section', 'mkd_restaurant'),
			'new_item_name'     => __('New Menu Section Name', 'mkd_restaurant'),
			'menu_name'         => __('Menu Sections', 'mkd_restaurant'),
		);

		register_taxonomy($this->taxBase, array($this->base), array(
			'hierarchical'      => true,
			'labels'            => $labels,
			'show_ui'           => true,
			'query_var'         => true,
			'show_admin_column' => true,
			'rewrite'           => array('slug' => 'menu-section'),
		));
	}

}