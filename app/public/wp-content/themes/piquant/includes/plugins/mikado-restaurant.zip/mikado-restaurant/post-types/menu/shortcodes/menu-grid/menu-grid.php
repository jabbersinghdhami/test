<?php
namespace MikadoRestaurant\CPT\Menu\Shortcodes\MenuGrid;

use MikadoRestaurant\Lib\ShortcodeInterface;
use MikadoRestaurant\Lib\MenuQuery;

class MenuGrid implements ShortcodeInterface {
	private $base;

	/**
	 * MenuGrid constructor.
	 */
	public function __construct() {
		$this->base = 'mkdf_restaurant_menu_grid';

		add_action('vc_before_init', array($this, 'vcMap'));
	}


	public function getBase() {
		return $this->base;
	}

	public function vcMap() {
		vc_map(array(
			'name'                      => 'Mikado Menu Grid',
			'base'                      => $this->base,
			'category'                  => 'by MIKADO',
			'icon'                      => '',
			'allowed_container_element' => 'vc_row',
			'params'                    => array_merge(
				array(
					array(
						'type'        => 'dropdown',
						'heading'     => 'Number of Columns',
						'param_name'  => 'number_of_cols',
						'value'       => array(
							'One Column'    => 'one-col',
							'Two Columns'   => 'two-cols',
							'Three Columns' => 'three-cols',
							'Four Columns'  => 'four-cols'
						),
						'admin_label' => true,
						'description' => 'Set number of columns'
					),
					array(
						'type'        => 'dropdown',
						'heading'     => 'Image Proportions',
						'param_name'  => 'image_proportions',
						'value'       => array(
							'Original'  => 'full',
							'Square'    => 'square',
							'Landscape' => 'landscape',
							'Portrait'  => 'portrait'
						),
						'admin_label' => true,
						'description' => 'Choose menu item image size'
					)
				),
				MenuQuery::getInstance()->queryVCParams()
			)
		));
	}

	public function render($atts, $content = null) {
		$defaultAtts = array(
			'number_of_cols' => '',
			'image_proportions' => ''
		);

		$defaultAtts = array_merge($defaultAtts, MenuQuery::getInstance()->getShortcodeAtts());

		$params = shortcode_atts($defaultAtts, $atts);
		$query  = MenuQuery::getInstance()->buildQueryObject($params);
		$gridItemParams = array(
			'image_proportion' => $this->getImageProportionName($params)
		);

		$holderClasses = $this->getHolderClasses($params);

		$html = '<div '.mkd_restaurant_get_class_attribute($holderClasses).'>';

		if($query->have_posts()) {
			$html .= '<ul class="mkdf-mg-holder clearfix">';

			while($query->have_posts()) {
				$query->the_post();
				$html .= mkd_restaurant_get_shortcode_module_template_part('menu', 'menu-grid/templates/menu-grid-item', '', $gridItemParams);
			}

			$html .= '</ul>';

			wp_reset_postdata();
		} else {
			$html .= '<p>'.esc_html__('No menu items match your query', 'mkd_restaurant').'</p>';
		}

		$html .= '</div>';

		return $html;
	}

	private function getImageProportionName($params) {
		$imageProportion = 'full';

		if(!empty($params['image_proportions'])) {
			switch($params['image_proportions']) {
				case 'square':
					$imageProportion = 'portfolio-square';
					break;
				case 'portrait':
					$imageProportion = 'portfolio-portrait';
					break;
				case 'landscape':
					$imageProportion = 'portfolio-landscape';
					break;
				default:
					$imageProportion = 'full';
					break;
			}
		}

		return $imageProportion;
	}

	private function getHolderClasses($params) {
		$classes = array('mkdf-menu-grid');

		if(!empty($params['number_of_cols'])) {
			$classes[] = 'mkdf-mg-'.$params['number_of_cols'];
		}

		return $classes;
	}
}

