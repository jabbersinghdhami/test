<?php
namespace MikadoRestaurant\Lib;

/**
 * Class MenuQuery
 * @package MikadoRestaurant\Lib
 */
class MenuQuery {
	/**
	 * @var private instance of current class
	 */
	private static $instance;

	/**
	 * Private constuct because of Singletone
	 */
	private function __construct() {
	}

	/**
	 * Private sleep because of Singletone
	 */
	private function __wakeup() {
	}

	/**
	 * Private clone because of Singletone
	 */
	private function __clone() {
	}

	/**
	 * Returns current instance of class
	 * @return ShortcodeLoader
	 */
	public static function getInstance() {
		if(self::$instance == null) {
			return new self;
		}

		return self::$instance;
	}

	/**
	 *
	 *
	 * @return array
	 */
	public function queryVCParams() {
		return array(
			array(
				'type'        => 'dropdown',
				'heading'     => 'Order By',
				'param_name'  => 'order_by',
				'value'       => array(
					'Menu Order' => 'menu_order',
					'Title'      => 'title',
					'Date'       => 'date'
				),
				'admin_label' => true,
				'save_always' => true,
				'description' => '',
				'group'       => 'Query'
			),
			array(
				'type'        => 'dropdown',
				'heading'     => 'Order',
				'param_name'  => 'order',
				'value'       => array(
					'ASC'  => 'ASC',
					'DESC' => 'DESC',
				),
				'admin_label' => true,
				'save_always' => true,
				'description' => '',
				'group'       => 'Query'
			),
			array(
				'type'        => 'textfield',
				'heading'     => 'Menu Section',
				'param_name'  => 'menu_section',
				'value'       => '',
				'admin_label' => true,
				'description' => 'Enter one menu section slug (leave empty for showing all menu sections)',
				'group'       => 'Query'
			),
			array(
				'type'        => 'textfield',
				'heading'     => 'Number of Menu Items',
				'param_name'  => 'number',
				'value'       => '-1',
				'admin_label' => true,
				'description' => '(enter -1 to show all)',
				'group'       => 'Query'
			)
		);
	}

	/**
	 * Returns array of parameters to be used inside shortcodes
	 *
	 * @return array
	 */
	public function getShortcodeAtts() {
		return array(
			'order_by'     => '',
			'order'        => '',
			'menu_section' => '',
			'number'       => ''
		);
	}

	/**
	 * Returns an instance of WP_Query class based on proved params
	 *
	 * @param $params
	 *
	 * @return \WP_Query
	 */
	public function buildQueryObject($params) {
		$queryParams = array(
			'post_type'      => 'restaurant-menu-item',
			'orderby'        => $params['order_by'],
			'order'          => $params['order'],
			'posts_per_page' => $params['number']
		);

		$orderBy      = !empty($params['order_by']) ? $params['order_by'] : 'date';
		$order        = !empty($params['order']) ? $params['order'] : 'DESC';
		$postsPerPage = !empty($params['number']) ? $params['number'] : '';

		$queryParams['orderby'] = $orderBy;
		$queryParams['order']   = $order;

		if($postsPerPage !== '') {
			$queryParams['posts_per_page'] = $postsPerPage;
		}

		if(!empty($params['menu_section'])) {
			$queryParams['restaurant-menu-section'] = $params['menu_section'];
		}

		return new \WP_Query($queryParams);
	}
}