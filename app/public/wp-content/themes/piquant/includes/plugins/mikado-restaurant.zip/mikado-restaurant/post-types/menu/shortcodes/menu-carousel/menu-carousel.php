<?php
namespace MikadoRestaurant\CPT\Menu\Shortcodes\MenuCarousel;

use MikadoRestaurant\Lib\MenuQuery;
use MikadoRestaurant\Lib\ShortcodeInterface;

class MenuCarousel implements ShortcodeInterface {
	private $base;

	/**
	 * MenuCarousel constructor.
	 */
	public function __construct() {
		$this->base = 'mkdf_restaurant_menu_carousel';

		add_action('vc_before_init', array($this, 'vcMap'));
	}

	public function getBase() {
		return $this->base;
	}

	public function vcMap() {
		vc_map(array(
			'name'                      => 'Mikado Menu Carousel',
			'base'                      => $this->base,
			'category'                  => 'by MIKADO',
			'icon'                      => '',
			'allowed_container_element' => 'vc_row',
			'params'                    => array_merge(
				array(
					array(
						'type'        => 'dropdown',
						'heading'     => 'Image Proportions',
						'param_name'  => 'image_proportions',
						'value'       => array(
							'Original'  => 'full',
							'Square'    => 'square',
							'Landscape' => 'landscape',
							'Portrait'  => 'portrait'
						),
						'admin_label' => true,
						'description' => 'Choose menu item image size'
					),
					array(
						'type'        => 'dropdown',
						'heading'     => 'Navigation Style',
						'param_name'  => 'navigation_style',
						'value'       => array(
							''      => '',
							'Dark'  => 'dark',
							'Light' => 'light'
						),
						'admin_label' => true,
						'description' => 'Choose menu item image size'
					),
				),
				MenuQuery::getInstance()->queryVCParams()
			)
		));
	}

	public function render($atts, $content = null) {
		$defaultAtts = array(
			'image_proportions' => '',
			'navigation_style'  => ''
		);

		$defaultAtts = array_merge($defaultAtts, MenuQuery::getInstance()->getShortcodeAtts());
		$params      = shortcode_atts($defaultAtts, $atts);

		$query = MenuQuery::getInstance()->buildQueryObject($params);

		$gridItemParams = array(
			'image_proportion' => $this->getImageProportionName($params)
		);

		$holderClasses = array(
			'mkdf-menu-carousel-holder',
			'mkdf-carousel-navigation'
		);

		if($params['navigation_style'] !== '') {
			$holderClasses[] = 'mkdf-carousel-navigation-'.$params['navigation_style'];
		}

		$html = '<div '.mkd_restaurant_get_class_attribute($holderClasses).'>';

		if($query->have_posts()) {
			$html .= '<ul class="mkdf-menu-carousel">';

			while($query->have_posts()) {
				$query->the_post();
				$html .= mkd_restaurant_get_shortcode_module_template_part('menu', 'menu-grid/templates/menu-grid-item', '', $gridItemParams);
			}

			$html .= '</ul>';

			wp_reset_postdata();
		} else {
			$html .= '<p>'.esc_html__('No menu items match your query', 'mkd_restaurant').'</p>';
		}

		$html .= '</div>';

		return $html;
	}

	private function getImageProportionName($params) {
		$imageProportion = 'full';

		if(!empty($params['image_proportions'])) {
			switch($params['image_proportions']) {
				case 'square':
					$imageProportion = 'portfolio-square';
					break;
				case 'portrait':
					$imageProportion = 'portfolio-portrait';
					break;
				case 'landscape':
					$imageProportion = 'portfolio-landscape';
					break;
				default:
					$imageProportion = 'full';
					break;
			}
		}

		return $imageProportion;
	}
}