<?php
namespace MikadoRestaurant\CPT\Menu\Shortcodes\MenuList;

use MikadoRestaurant\Lib\ShortcodeInterface;
use MikadoRestaurant\Lib\MenuQuery;

class MenuList implements ShortcodeInterface {
	private $base;

	public function __construct() {
		$this->base = 'mkdf_restaurant_menu_list';

		add_action('vc_before_init', array($this, 'vcMap'));
	}

	public function vcMap() {
		vc_map(array(
			'name'                      => 'Mikado Menu List',
			'base'                      => $this->base,
			'category'                  => 'by MIKADO',
			'icon'                      => '',
			'allowed_container_element' => 'vc_row',
			'params'                    => array_merge(
				array(
					array(
						'type'        => 'textfield',
						'heading'     => 'Title',
						'param_name'  => 'title',
						'value'       => '',
						'admin_label' => true
					),
					array(
						'type'        => 'dropdown',
						'heading'     => 'Title Position',
						'param_name'  => 'title_position',
						'value'       => array(
							'Left'   => '',
							'Center' => 'center'
						),
						'admin_label' => true,
						'save_always' => true
					),
					array(
						'type'        => 'dropdown',
						'heading'     => 'Show Featured Image?',
						'param_name'  => 'show_featured_image',
						'value'       => array(
							''    => '',
							'Yes' => 'yes',
							'No'  => 'no'
						),
						'admin_label' => true,
						'description' => 'Use this option to show featured image of menu items',
					)
				),
				MenuQuery::getInstance()->queryVCParams()
			)
		));
	}

	public function getBase() {
		return $this->base;
	}

	public function render($atts, $content = null) {
		$defaultAtts = array(
			'show_featured_image' => '',
			'title'               => '',
			'title_position'      => ''
		);

		$defaultAtts = array_merge($defaultAtts, MenuQuery::getInstance()->getShortcodeAtts());

		$params = shortcode_atts($defaultAtts, $atts);
		$query  = MenuQuery::getInstance()->buildQueryObject($params);

		$listItemParams = array(
			'show_featured_image' => $params['show_featured_image']
		);

		$holderClasses = $this->getHolderClasses($params);
		$titleClasses = array(
			'mkdf-mlw-title-holder'
		);

		$titleClasses[] = 'mkdf-mlw-title-holder-'.$params['title_position'];

		$html = '<div '.mkd_restaurant_get_class_attribute($holderClasses).'>';

		if($params['title'] !== '') {
			$html .= '<div '.mkd_restaurant_get_class_attribute($titleClasses).'>';
			if($params['title_position'] === 'center') {
				$html .= '<span class="mkdf-mlw-border"><span class="mkdf-mlw-border-inner"></span></span>';
			}
			$html .= '<h2 class="mkdf-mlw-title">'.esc_html($params['title']).'</h2>';
			$html .= '<span class="mkdf-mlw-border"><span class="mkdf-mlw-border-inner"></span></span>';
			$html .= '</div>';
		}

		if($query->have_posts()) {
			$html .= '<ul class="mkdf-ml-holder">';

			while($query->have_posts()) {
				$query->the_post();
				$html .= mkd_restaurant_get_shortcode_module_template_part('menu', 'menu-list/templates/menu-list-item', '', $listItemParams);
			}

			$html .= '</ul>';

			wp_reset_postdata();
		} else {
			$html .= '<p>'.esc_html__('No menu items match your query', 'mkd_restaurant').'</p>';
		}

		$html .= '</div>';

		return $html;
	}

	private function getHolderClasses($params) {
		$classes = array('mkdf-menu-list');

		if($params['show_featured_image'] === 'yes') {
			$classes[] = 'mkdf-ml-with-featured-image';
		}

		return $classes;
	}

}