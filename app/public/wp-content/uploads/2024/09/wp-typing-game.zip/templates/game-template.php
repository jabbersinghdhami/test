<div class="container">
  <h2>Typing Challenge</h2>
  <p id="paragraph">The quick brown fox jumps over the lazy dog again and again without stopping to rest.</p>
  <textarea id="userInput" placeholder="Start typing here..." rows="4" cols="50"></textarea>
</div>
