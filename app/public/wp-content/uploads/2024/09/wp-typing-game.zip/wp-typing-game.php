<?php
/*
Plugin Name: Typing Game Plugin
Description: A typing game for registered users where they can track their attempts, wins, and losses.
Version: 1.0
Author: Your Name
*/

// Ensure this file is being run within WordPress
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// Enqueue scripts and styles
function wp_typing_game_enqueue_scripts() {
    wp_enqueue_style( 'typing-game-style', plugin_dir_url( __FILE__ ) . 'assets/style.css' );
    wp_enqueue_script( 'typing-game-script', plugin_dir_url( __FILE__ ) . 'assets/script.js', array('jquery'), null, true );
    wp_localize_script( 'typing-game-script', 'gameData', array(
        'ajaxUrl' => admin_url( 'admin-ajax.php' )
    ));
}
add_action( 'wp_enqueue_scripts', 'wp_typing_game_enqueue_scripts' );

// Create a shortcode for the typing game
function wp_typing_game_shortcode() {
    if ( is_user_logged_in() ) {
        ob_start();
        include plugin_dir_path( __FILE__ ) . 'templates/game-template.php';
        return ob_get_clean();
    } else {
        return '<p>Please log in to play the typing game.</p>';
    }
}
add_shortcode( 'typing_game', 'wp_typing_game_shortcode' );

// Handle Ajax requests to save game results
function wp_typing_game_save_result() {
    if ( is_user_logged_in() && isset($_POST['score']) ) {
        global $wpdb;
        $table_name = $wpdb->prefix . 'typing_game_results';
        $user_id = get_current_user_id();
        $score = intval( $_POST['score'] );
        $time_taken = floatval( $_POST['time_taken'] );
        $status = sanitize_text_field( $_POST['status'] );

        // Insert the result into the database
        $wpdb->insert( $table_name, array(
            'user_id'    => $user_id,
            'score'      => $score,
            'time_taken' => $time_taken,
            'status'     => $status,
            'created_at' => current_time('mysql')
        ));

        wp_send_json_success( 'Result saved successfully!' );
    } else {
        wp_send_json_error( 'You must be logged in to submit results.' );
    }
}
add_action( 'wp_ajax_save_typing_game_result', 'wp_typing_game_save_result' );

// Create a database table to store game results
function wp_typing_game_create_table() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'typing_game_results';
    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE $table_name (
      id mediumint(9) NOT NULL AUTO_INCREMENT,
      user_id bigint(20) NOT NULL,
      score int NOT NULL,
      time_taken float NOT NULL,
      status varchar(10) NOT NULL,
      created_at datetime DEFAULT CURRENT_TIMESTAMP NOT NULL,
      PRIMARY KEY  (id)
    ) $charset_collate;";

    require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
    dbDelta( $sql );
}
register_activation_hook( __FILE__, 'wp_typing_game_create_table' );
