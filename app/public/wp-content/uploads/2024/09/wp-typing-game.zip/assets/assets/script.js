jQuery(document).ready(function($) {
    let startTime;
    const targetText = "The quick brown fox jumps over the lazy dog again and again without stopping to rest.";

    $('#userInput').on('focus', function() {
        startTime = new Date().getTime(); // Start timer when user starts typing
    });

    $('#userInput').on('input', function() {
        const userInput = $(this).val();

        // Check if user has typed the exact paragraph
        if (userInput === targetText) {
            const timeTaken = ((new Date().getTime() - startTime) / 1000).toFixed(2); // Calculate time taken in seconds
            let status = timeTaken <= 30 ? 'win' : 'lose'; // Check if time taken is less than or equal to 30 seconds
            let score = status === 'win' ? 100 : 0; // Assign score

            // Send result via Ajax to save in the database
            $.post(gameData.ajaxUrl, {
                action: 'save_typing_game_result',
                score: score,
                time_taken: timeTaken,
                status: status
            }, function(response) {
                if (response.success) {
                    // Display result in a pop-up
                    let resultColor = status === 'win' ? 'green' : 'red';
                    let popupHTML = `
                        <div id="resultPopup" style="background-color:${resultColor}; padding: 20px; position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%); border-radius: 10px; box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2); z-index: 9999;">
                            <h2 style="color: white;">You ${status.toUpperCase()}!</h2>
                            <p style="color: white;">Time taken: ${timeTaken} seconds</p>
                            <button id="closePopup" style="padding: 10px; background-color: white; color: black; border: none; cursor: pointer;">Close</button>
                        </div>
                    `;

                    $('body').append(popupHTML); // Add popup to the DOM

                    // Close the pop-up
                    $('#closePopup').on('click', function() {
                        $('#resultPopup').remove();
                        $('#userInput').val(''); // Clear input field for replay
                    });

                } else {
                    alert(response.data); // If saving fails, show an error
                }
            });
        }
    });
});
